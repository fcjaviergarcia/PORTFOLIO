<html>
    <head>
        <meta charset="UTF-8">
        <title>Cerrar sesion</title>
        <link rel="stylesheet" href="estilo_default.css">
        <link rel="stylesheet" href="estilo_cierre.css">
        <link rel="icon" href="https://th.bing.com/th/id/OIP.4HrjGKGCxbuUMpKH3KMwuAHaHv?rs=1&pid=ImgDetMain" type="image/jpg">
    </head>
    <body>
    <?php
session_start();
// Eliminar la cookie
setcookie("usuario", "", time() - 3600, "/");  // La cookie se elimina estableciendo una fecha pasada

// Eliminar todos los datos de la sesión
session_unset();
session_destroy();

// Redirigir al login
header("Location: index.php");
exit();
?>
    </body>
</html>