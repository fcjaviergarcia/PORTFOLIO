<?php
// Iniciar la sesión
session_start();

// Verificar si la cookie de usuario está presente
if (!isset($_COOKIE['usuario'])) {
    // Redirigir a login si no hay cookie
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "foro");

// Obtener el nombre de usuario de la cookie
$usuario = $_COOKIE['usuario'];

// Si se ha enviado el formulario de eliminación
if (isset($_POST['id_publicacion'])) {
    // Obtener el ID de la publicación seleccionada
    $id_publicacion = $_POST['id_publicacion'];

    // Verificar si el usuario es el autor de la publicación
    $query = "SELECT autor FROM publicaciones WHERE id_publicacion = $id_publicacion";
    $resultado = $conexion->query($query);

    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();

        // Si el autor de la publicación coincide con el usuario
        if ($fila['autor'] == $usuario) {
            // Eliminar primero las respuestas asociadas a la publicación
            $query_delete_respuestas = "DELETE FROM respuestas WHERE id_publicacion = $id_publicacion";
            if ($conexion->query($query_delete_respuestas) === TRUE) {
                // Ahora eliminar la publicación
                $query_delete = "DELETE FROM publicaciones WHERE id_publicacion = $id_publicacion";
                if ($conexion->query($query_delete) === TRUE) {
                    echo "<script>alert('Publicación eliminada exitosamente.'); window.location.href = 'perfil.php';</script>";
                } else {
                    echo "<script>alert('Error al eliminar la publicación.');</script>";
                }
            } else {
                echo "<script>alert('Error al eliminar las respuestas.');</script>";
            }
        } else {
            echo "<script>alert('No tienes permiso para eliminar esta publicación.');</script>";
        }
    } else {
        echo "<script>alert('Publicación no encontrada.');</script>";
    }
}

// Obtener las publicaciones del usuario
$query = "SELECT id_publicacion, titulo FROM publicaciones WHERE autor = '$usuario'";
$resultado = $conexion->query($query);

?>

<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Eliminar Tema</title>
        <link rel="stylesheet" href="estilo_default.css">
        <link rel="stylesheet" href="estilo_eliminartema.css">
    </head>
    <body>
    <nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
                <li><a href="crearusuario.php">Registrarse</a></li>
                <li><a href="login.php">Iniciar sesión</a></li>
                <li><a href="cierre.php">Cerrar sesión</a></li>
                <li><a href="eliminar.php">Eliminar cuenta</a></li>
                <li><a href="perfil.php">Foro</a></li>
        </ul>
    </nav>

        <h1>Formulario para eliminar un tema</h1>
        <form action="eliminartema.php" method="POST">
            <label for="tema">Selecciona un tema para eliminar:</label>
            <select name="id_publicacion" id="tema">
                <?php
                // Verificar si el usuario tiene publicaciones
                if ($resultado->num_rows > 0) {
                    // Mostrar las publicaciones del usuario
                    while ($fila = $resultado->fetch_assoc()) {
                        echo '<option value="' . $fila['id_publicacion'] . '">' . $fila['titulo'] . '</option>';
                    }
                } else {
                    // Si no tiene publicaciones, mostrar una opción desactivada
                    echo '<option disabled selected>No tienes publicaciones para eliminar.</option>';
                }
                ?>
            </select>
            <button type="submit">Eliminar</button>
        </form>
    </body>
</html>
