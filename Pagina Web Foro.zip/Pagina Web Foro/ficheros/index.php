<?php
// Archivo donde se guardarán las visitas
$archivo = "contador.txt";

// Leemos el valor actual del contador
$contador = (int)file_get_contents($archivo);

// Incrementamos el contador
$contador++;

// Guardamos el nuevo valor en el archivo
file_put_contents($archivo, $contador);
?>
<html>
    <head>
        <script src="cookies.js" defer></script>
        <meta charset="UTF-8">
        <title>Bienvenido</title>
        <link rel="stylesheet" href="estilo_default.css">
        <link rel="stylesheet" href="estilo_index.css">
        <link rel="icon" href="https://1.bp.blogspot.com/-g4mGPHYUIu8/XRvq_mtifcI/AAAAAAAAAQw/gtWgQMc5h7IDhM5cxkskTcVD78FwqKOmACLcBGAs/s1600/como-crear-un-foro-en-wordpress-con-wpforo.png" type="image/png">
      </head>
    <body>
    <div id="cookie-banner">
      <p>Este sitio web utiliza cookies para mejorar la experiencia del usuario. <br> Haz clic en cualquier parte para aceptar.</p>
    </div>
        <h1>Foro proyecto Aplicaciones Web</h1>
        <nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
                <li><a href="crearusuario.php">Registrarse</a></li>
                <li><a href="login.php">Iniciar sesión</a></li>
                <li><a href="cierre.php">Cerrar sesión</a></li>
                <li><a href="eliminar.php">Eliminar cuenta</a></li>
                <li><a href="perfil.php">Foro</a></li>
        </ul>
    </nav>
      <table>
          <thead>
            <tr>
              <td colspan="2" rowspan="2"><p>Bienvenido</p></td>
            </tr>
          </thead>
          <tbody>
            <tr>
                <td><a href="login.php">Conectarte</a></td>
                <td><a href="crearusuario.php">Crear una cuenta</a></td>
            </tr>
            </tbody>
            </tr>
          <tfoot>
            <tr>
              <td colspan=2>Personas que han visitado la web: <?php echo $contador;?> </td>
              </td>
            </tr>
            </tfoot>
      </table>
    </body>
</html>

