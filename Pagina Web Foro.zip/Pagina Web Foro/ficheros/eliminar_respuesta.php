<?php
// Iniciar la sesión
session_start();

// Verificar si la cookie de usuario está presente
if (!isset($_COOKIE['usuario'])) {
    // Si no hay cookie, redirigir a login
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "foro");
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Verificar si se ha enviado el formulario para eliminar
if (isset($_POST['id_respuesta']) && isset($_GET['id'])) {
    $id_respuesta = $_POST['id_respuesta'];
    $usuario = $_COOKIE['usuario'];
    $id_publicacion = $_GET['id']; // Obtener el id de la publicación desde la URL

    // Verificar si la respuesta pertenece al usuario
    $consulta_respuesta = "SELECT * FROM respuestas WHERE id_respuesta = '$id_respuesta' AND usuario = '$usuario'";
    $resultado_respuesta = mysqli_query($conexion, $consulta_respuesta);

    if (mysqli_num_rows($resultado_respuesta) > 0) {
        // Eliminar la respuesta
        $consulta_eliminar = "DELETE FROM respuestas WHERE id_respuesta = '$id_respuesta'";
        if (mysqli_query($conexion, $consulta_eliminar)) {
            // Redirigir al usuario a la misma página de la publicación
            echo "<script>
                    alert('Respuesta eliminada con éxito.');
                    window.location.href = 'respuesta.php?id=" . $id_publicacion . "'; // Mantener al usuario en la misma página
                  </script>";
        } else {
            echo "<script>alert('Error al eliminar la respuesta.'); window.location.href = 'respuesta.php?id=" . $id_publicacion . "';</script>";
        }
    } else {
        echo "<script>alert('No puedes eliminar esta respuesta.'); window.location.href = 'respuesta.php?id=" . $id_publicacion . "';</script>";
    }
}
?>
