<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login/Acceso al foro</title>
    <link rel="stylesheet" href="estilo_default.css">
    <link rel="stylesheet" href="estilo_login.css">
    <link rel="icon" href="https://th.bing.com/th/id/OIP.fyGIawMokjuYAbfGNpFT1AHaGm?rs=1&pid=ImgDetMain" type="image/jpg">
    </head>
<body>
<nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
                <li><a href="crearusuario.php">Registrarse</a></li>
                <li><a href="login.php">Iniciar sesión</a></li>
                <li><a href="cierre.php">Cerrar sesión</a></li>
                <li><a href="eliminar.php">Eliminar cuenta</a></li>
                <li><a href="perfil.php">Foro</a></li>
        </ul>
    </nav>
    <h1>Inicio de sesión</h1>
    <form action="login.php" method="POST">
    <table>
    <tr>
        <td class="izquierda"><label for="usuario">Usuario:</label></td>
        <td class="derecha"><input type="text" id="usuario" name="usuario"  required minlength="10" maxlength="30" pattern="^(?!\d)[A-Za-zñÑáéíóúü\d@#$%^&+=!]{10,30}$" title="Debe tener entre 10 y 30 caracteres, incluir un carácter especial y no comenzar con un número."></td>
    </tr>
    <tr>
        <td class="izquierda"><label for="contraseña">Contraseña:</label></td>
        <td class="derecha"><input type="password" id="contraseña" name="contraseña" required minlength="5" maxlength="20" pattern="^(?=.*[A-Z])(?=.*\d).{5,20}$" title="Debe contener al menos un número, una mayúscula y tener entre 5 y 20 caracteres."></td>
    </tr>
    <tr>
        <td colspan="2" class="botones">
        <input type="submit" value="Iniciar Sesión" id="enviar"></input>
        <input type="reset" id="resetear"></input>
        </td>
    </tr>
    </table></form>

    <?php
// Verificamos si el formulario fue enviado
if ($_POST) {
    // Conectamos a la base de datos
    $conexion = mysqli_connect("localhost", "root", "", "foro");

    // Recogemos los datos del formulario
    $usuario = $_POST['usuario'];
    $contraseña = $_POST['contraseña'];

    // Preparamos la consulta para comprobar si las credenciales existe en la base de datos
    $consulta = "SELECT * FROM usuario WHERE usuario = '$usuario' AND contraseña = '$contraseña'";
    $resultado = mysqli_query($conexion, $consulta);

    // Si encontramos al usuario en la base de datos
    if (mysqli_num_rows($resultado) > 0) {
        // El usuario existe, iniciamos sesión
        session_start(); // Iniciar sesión
        $_SESSION['usuario'] = $usuario; // Guardar el usuario en la sesión

        // Redirigir al usuario a otra página, por ejemplo, al foro
        header("Location: perfil.php");
    } else {
        // Si no existe, mostrar mensaje de error
        echo "<script>
        alert('Usuario o contraseña incorrectos.');
        </script>";
    }
}
?>
</body>
</html>
