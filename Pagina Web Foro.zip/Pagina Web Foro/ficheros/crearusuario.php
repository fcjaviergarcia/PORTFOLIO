<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Creación de usuario</title>
    <link rel="stylesheet" href="estilo_default.css">
    <link rel="stylesheet" href="estilo_crearusuario.css">
    <link rel="icon" href="https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExODI3aHNqbTdydHJ1bTRnMWF2MG91eGx4ZHR4NDNhemViemR3Z3V0ZiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/tHIRLHtNwxpjIFqPdV/giphy.gif" type="image/gif">
    </head>
<body>
<nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
                <li><a href="crearusuario.php">Registrarse</a></li>
                <li><a href="login.php">Iniciar sesión</a></li>
                <li><a href="cierre.php">Cerrar sesión</a></li>
                <li><a href="eliminar.php">Eliminar cuenta</a></li>
                <li><a href="perfil.php">Foro</a></li>
        </ul>
    </nav>
    <h1>Formulario de registro</h1>
    <form action="crearusuario.php" method="POST">
    <table>
    <tr>
        <td class="izquierda"><label for="usuario">Nombre de usuario:</label></td>
        <td class="derecha"><input type="text" id="usuario" name="usuario"  required minlength="10" maxlength="30" pattern="^(?!\d)[A-Za-zñÑáéíóúü\d@#$%^&+=!]{10,30}$" title="Debe tener entre 10 y 30 caracteres, incluir un carácter especial y no comenzar con un número."></td>
    </tr>
    <tr>
        <td class="izquierda"><label for="contrasena">Contraseña:</label></td>
        <td class="derecha"><input type="password" id="contrasena" name="contrasena" required minlength="5" maxlength="20" pattern="^(?=.*[A-Z])(?=.*\d).{5,20}$" title="Debe contener al menos un número, una mayúscula y tener entre 5 y 20 caracteres."></td>
    </tr>
    <tr>
        <td colspan="2" class="botones">
        <input type="submit" value="Registrarse" id="enviar"></input>
        <input type="reset" id="resetear"></input>
        </td>
    </tr>
    <tr>
        <td colspan="2" class="volver"><a href="javascript:history.back();">Volver</a><br>
        <a href="politica_de_privacidad.pdf" class="politica">Politica de privacidad</a></td>
    </tr>
    </table></form>
    <?php
if ($_POST) {
    // Recoger las variables del formulario
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    // Crear la conexión a la base de datos
    $conexion = mysqli_connect("localhost", "root", "", "foro");

    // Crear la consulta para verificar si el usuario ya existe
    $consulta_verificar = "SELECT * FROM usuario WHERE usuario = '$usuario'";
    $resultado_verificar = mysqli_query($conexion, $consulta_verificar);

    // Verificar si el usuario ya existe
    if (mysqli_num_rows($resultado_verificar) > 0) {
        echo "El nombre de usuario ya existe. Por favor, elige otro.";
    } else {
        // Crear la consulta para insertar el nuevo usuario
        $consulta_insertar = "INSERT INTO usuario (usuario, contraseña) VALUES ('$usuario', '$contrasena')";

        // Ejecutar la consulta
        $resultado_insertar = mysqli_query($conexion, $consulta_insertar);
        // Verificar si la consulta se ejecutó correctamente
        if ($resultado_insertar) {
            echo "Usuario creado exitosamente.";
            // Redirigir a la página de login
            header("Location: login.php");
        } else {
            echo "<script>
            alert('Error al crear el usuario');
            </script>";        }
    }
}
?>
</body>
</html>
