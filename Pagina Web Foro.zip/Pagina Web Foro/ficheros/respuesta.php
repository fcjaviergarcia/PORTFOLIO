<?php
// Iniciar la sesión
session_start();

// Verificar si la cookie de usuario está presente
if (!isset($_COOKIE['usuario'])) {
    // Si no hay cookie, redirigir a login
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "foro");
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el id_publicacion desde la URL
if (isset($_GET['id'])) {
    $id_publicacion = $_GET['id'];

    // Obtener los detalles de la publicación
    $consulta_publicacion = "SELECT * FROM publicaciones WHERE id_publicacion = '$id_publicacion'";
    $resultado_publicacion = mysqli_query($conexion, $consulta_publicacion);
    
    // Verificar si se encontró la publicación
    if (mysqli_num_rows($resultado_publicacion) > 0) {
        $publicacion = mysqli_fetch_assoc($resultado_publicacion);
        
        // Obtener el número de respuestas
        $consulta_respuestas = "SELECT COUNT(*) as total_respuestas FROM respuestas WHERE id_publicacion = '$id_publicacion'";
        $resultado_respuestas = mysqli_query($conexion, $consulta_respuestas);
        $row_respuestas = mysqli_fetch_assoc($resultado_respuestas);

        // Obtener el número de "me gusta" y "no me gusta"
        $consulta_votos = "SELECT likes, dislikes FROM publicaciones WHERE id_publicacion = '$id_publicacion'";
        $resultado_votos = mysqli_query($conexion, $consulta_votos);
        $row_votos = mysqli_fetch_assoc($resultado_votos);

        $total_likes = $row_votos['likes'];
        $total_dislikes = $row_votos['dislikes'];
    } else {
        echo "Publicación no encontrada.";
        exit();
    }
} else {
    echo "No se ha recibido el ID de la publicación.";
    exit();
}

// Procesar la respuesta si se recibe un POST
if (isset($_COOKIE['usuario']) && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['respuesta'])) {
    $respuesta = $_POST['respuesta'];
    $usuario = $_COOKIE['usuario']; // Usar la cookie para obtener el nombre del usuario

    // Insertar la respuesta en la base de datos
    $consulta_insertar_respuesta = "INSERT INTO respuestas (id_publicacion, usuario, contenido) VALUES ('$id_publicacion', '$usuario', '$respuesta')";
    if (mysqli_query($conexion, $consulta_insertar_respuesta)) {
        // Redirigir para ver la misma página y mostrar respuestas actualizadas
        header("Location: respuesta.php?id=$id_publicacion");
        exit();
    } else {
        echo "Error al insertar la respuesta.";
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Respuestas</title>
    <link rel="stylesheet" href="estilo_default.css">
    <link rel="stylesheet" href="estilo_respuesta.css">
    <link rel="icon" href="https://th.bing.com/th/id/R.6eee63a68eb5a6821dd66204813c36ac?rik=4fmMt6%2fa11vtWw&pid=ImgRaw&r=0" type="image/jpg">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
<nav class="menu">
    <ul>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="crearusuario.php">Registrarse</a></li>
        <li><a href="login.php">Iniciar sesión</a></li>
        <li><a href="cierre.php">Cerrar sesión</a></li>
        <li><a href="eliminar.php">Eliminar cuenta</a></li>
        <li><a href="perfil.php">Foro</a></li>
    </ul>
</nav>
<div id="contenedor">
<div class="header">
    <h2>Leyendo Tema: <?php echo $publicacion['titulo']; ?> | Autor: <?php echo $publicacion['autor']; ?></h2>
</div>
<div class="publicacion">
    <h3>Contenido del Tema:</h3>
    <p><?php echo nl2br($publicacion['contenido']); ?></p>

    <?php
    // Verificar si hay un archivo adjunto
    if (!empty($publicacion['archivo'])) {
        // Extraer el nombre del archivo de la ruta
        $nombre_archivo = basename($publicacion['archivo']);
        
        // Mostrar el nombre del archivo junto con el enlace para descargarlo
        echo '<p>Archivo adjunto: ' . $nombre_archivo . ' (<a href="' . $publicacion['archivo'] . '" download>Descargar</a>)</p>';
    }
    ?>
</div>

<br><br>
<h3>Respuestas de los usuarios:</h3>
<table border="1px">
    <tr>
        <th>Nombre Usuario</th>
        <th>Respuesta</th>
        <th>Fecha Respuesta</th>
        <th>Acción</th>
    </tr>

    <?php
    // Obtener todas las respuestas de la base de datos
    $consulta_respuestas = "SELECT * FROM respuestas WHERE id_publicacion = '$id_publicacion' ORDER BY fecha DESC";
    $resultado_respuestas = mysqli_query($conexion, $consulta_respuestas);

    if (mysqli_num_rows($resultado_respuestas) > 0) {
        while ($respuesta = mysqli_fetch_assoc($resultado_respuestas)) {
            echo "<tr>";
            echo "<td>" . $respuesta['usuario'] . "</td>";
            echo "<td>" . $respuesta['contenido'] . "</td>";
            echo "<td>" . $respuesta['fecha'] . "</td>";
            
            // Siempre mostrar la celda de la columna "Acción", aunque esté vacía
            echo "<td>";
            // Mostrar el botón solo si el usuario es el que escribió la respuesta
            if ($_COOKIE['usuario'] == $respuesta['usuario']) {
                echo "<form action='eliminar_respuesta.php?id=$id_publicacion' method='POST'>
                        <input type='hidden' name='id_respuesta' value='" . $respuesta['id_respuesta'] . "'>
                        <input type='submit' value='Eliminar'>
                      </form>";
            }
            echo "</td>";
            
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No hay respuestas aún.</td></tr>";
    }
    ?>
</table>

<br><br>
<h3>Introduce una respuesta:</h3>
<form action="respuesta.php?id=<?php echo $id_publicacion; ?>" method="POST">
    <textarea name="respuesta" rows="4" cols="50"></textarea><br>
    <input type="submit" value="Publicar respuesta">
</form>
<br><br>
<!-- Botones para votar -->
<form action="javascript:void(0);" method="POST">
    <span id="likediv"><img src="../imagenes/like.png" id="like_button" style="cursor: pointer;"></span>
    <span id="dislikediv"><img src="../imagenes/dislike.png" id="dislike_button" style="cursor: pointer;"></span>
</form>

<p>Me gusta: <span id="likes_count"><?php echo $total_likes; ?></span> | No me gusta: <span id="dislikes_count"><?php echo $total_dislikes; ?></span></p>

<script>
$(document).ready(function(){
    // Botón "Me gusta"
    $("#like_button").click(function(){
        $.post("votar.php", { id_publicacion: <?php echo $id_publicacion; ?>, voto: "like" }, function(data) {
            // Verificar si la respuesta contiene los nuevos valores
            if (data.likes !== undefined && data.dislikes !== undefined) {
                // Actualizar el contador de likes
                $("#likes_count").text(data.likes);
                // Actualizar el contador de dislikes
                $("#dislikes_count").text(data.dislikes);
            } else {
                alert("Error al actualizar los votos.");
            }
        }, "json");
    });

    // Botón "No me gusta"
    $("#dislike_button").click(function(){
        $.post("votar.php", { id_publicacion: <?php echo $id_publicacion; ?>, voto: "dislike" }, function(data) {
            // Verificar si la respuesta contiene los nuevos valores
            if (data.likes !== undefined && data.dislikes !== undefined) {
                // Actualizar el contador de dislikes
                $("#dislikes_count").text(data.dislikes);
                // Actualizar el contador de likes
                $("#likes_count").text(data.likes);
            } else {
                alert("Error al actualizar los votos.");
            }
        }, "json");
    });
});
</script>
</div>
</body>
</html>
