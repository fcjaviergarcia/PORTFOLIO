function validarFormulario() {
    // Obtener los elementos del formulario
    var titulo = document.getElementById('titulo');
    var contenido = document.getElementById('contenido');
    
    // Verificar si el campo de título es válido
    //trim elimina espacios en blancos
    if (titulo.value.trim() === "" || titulo.value.length < 1) {
      titulo.style.border = '2px solid red';  // Resaltar el borde en rojo
      alert("No se puede dejar el contenido ni el titulo vacio");
      return false;  // Evitar el envío del formulario
    } else {
        console.log("titulo bien")
    }
  
    // Verificar si el campo de contenido es válido
    if (contenido.value.trim() === "" || contenido.value.length < 1) {
      contenido.style.border = '2px solid red';  // Resaltar el borde en rojo
      alert("El campo Contenido es obligatorio y debe tener al menos 1 carácter.");
      return false;  // Evitar el envío del formulario
    } else {
        console.log("contenido bien")
    }
    
    // Si todo está correcto, el formulario se envía
    alert("Formulario válido, enviando...");
    return true;  // Permitir el envío del formulario
  }