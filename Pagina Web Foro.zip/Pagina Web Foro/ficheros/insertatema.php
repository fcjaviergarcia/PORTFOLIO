<?php
// Iniciar la sesión
session_start();

// Verificar si la cookie de usuario está presente
if (!isset($_COOKIE['usuario'])) {
    // Redirigir a login si no hay cookie
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "foro");

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $autor = $_COOKIE['usuario']; // Obtener el nombre de usuario desde la cookie
    $archivoRuta = ""; // Inicializar variable para la ruta del archivo

    // Verificar si se ha subido un archivo
if (!empty($_FILES['archivo']['name'])) {
    $directorioSubida = "../uploads/";
    $archivoNombre = basename($_FILES['archivo']['name']);
    
    // Crear un nombre para el archivo combinando el título de la publicación y el nombre del archivo
    $archivoRuta = $directorioSubida . str_replace(" ", "_", strtolower($titulo)) . "_" . $archivoNombre;
    
    // Mover el archivo al directorio de subida
    if (!move_uploaded_file($_FILES['archivo']['tmp_name'], $archivoRuta)) {
        echo "<script>alert('Error al subir el archivo.');</script>";
        $archivoRuta = "";
    }
}

    // Verificar que los campos no estén vacíos
    if (!empty($titulo) && !empty($contenido)) {
        // Crear la consulta SQL
        $consulta = "INSERT INTO publicaciones (autor, contenido, titulo, archivo) VALUES ('$autor', '$contenido', '$titulo', '$archivoRuta')";

        // Ejecutar la consulta
        if ($conexion->query($consulta)) {
            echo "<script>alert('Tema creado con éxito'); window.location.href = 'perfil.php';</script>";
        } else {
            echo "<script>alert('Error al crear el tema. Intenta nuevamente.');</script>";
        }
    } else {
        echo "<script>alert('Por favor, completa todos los campos.');</script>";
    }
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Insertar nuevo tema</title>
    <link rel="stylesheet" href="estilo_default.css">
    <link rel="stylesheet" href="estilo_insertatema.css">
    <link rel="icon" href="https://i.pinimg.com/originals/41/b6/6e/41b66e1ef1f87c8623417771814b535d.jpg" type="image/jpg">
    <script src="insertatema.js" defer></script>
</head>
<body>
<nav class="menu">
    <ul>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="crearusuario.php">Registrarse</a></li>
        <li><a href="login.php">Iniciar sesión</a></li>
        <li><a href="cierre.php">Cerrar sesión</a></li>
        <li><a href="eliminar.php">Eliminar cuenta</a></li>
        <li><a href="perfil.php">Foro</a></li>
    </ul>
</nav>
<h1>Formulario para insertar nuevo tema</h1>
<form action="insertatema.php" method="post" enctype="multipart/form-data" onsubmit="return validarFormulario()">
    <table>
        <tr>
            <td class="izquierda"><label for="titulo">Título:</label></td>
            <td class="derecha"><input type="text" id="titulo" name="titulo"></td>
        </tr>
        <tr>
            <td class="izquierda"><label for="contenido">Contenido:</label></td>
            <td class="derecha"><textarea id="contenido" name="contenido" rows="8" cols="20"></textarea></td>
        </tr>
        <tr>
            <td class="izquierda"><label for="archivo">Subir archivo:</label></td>
            <td class="derecha"><input type="file" id="archivo" name="archivo"></td>
        </tr>
        <tr>
            <td class="centro" colspan="2">
                <input type="submit" value="Publicar" class="publicar">
                <input type="reset" value="Resetear" class="resetear">
            </td>
        </tr>
    </table>
</form>
</body>
</html>
