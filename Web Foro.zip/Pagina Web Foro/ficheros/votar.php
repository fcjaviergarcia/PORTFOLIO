<?php
// Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "foro");
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

if (isset($_POST['id_publicacion']) && isset($_POST['voto'])) {
    $id_publicacion = $_POST['id_publicacion'];
    $voto = $_POST['voto'];

    // Actualizar el número de votos según el tipo de voto (like o dislike)
    if ($voto == "like") {
        $consulta = "UPDATE publicaciones SET likes = likes + 1 WHERE id_publicacion = '$id_publicacion'";
    } elseif ($voto == "dislike") {
        $consulta = "UPDATE publicaciones SET dislikes = dislikes + 1 WHERE id_publicacion = '$id_publicacion'";
    }

    if (mysqli_query($conexion, $consulta)) {
        // Obtener los nuevos valores de "likes" y "dislikes"
        $consulta_votos = "SELECT likes, dislikes FROM publicaciones WHERE id_publicacion = '$id_publicacion'";
        $resultado_votos = mysqli_query($conexion, $consulta_votos);
        $row_votos = mysqli_fetch_assoc($resultado_votos);

        // Devolver los nuevos valores como un JSON
        echo json_encode(array(
            'likes' => $row_votos['likes'],
            'dislikes' => $row_votos['dislikes']
        ));
    } else {
        echo json_encode(array('error' => 'Error al actualizar los votos'));
    }
} else {
    echo json_encode(array('error' => 'Datos inválidos'));
}
?>
