<html>
    <head>
        <meta charset="UTF-8">
        <title>Publicaciones</title>
        <link rel="stylesheet" href="estilo_default.css">
        <link rel="stylesheet" href="estilo_perfil.css">
        <link rel="icon" href="https://th.bing.com/th/id/R.3db05f40f9bfbfa4818e5f841359ac18?rik=i9uCGc2yoCWfNA&riu=http%3a%2f%2fspeedyclearance.uk%2fwp-content%2fuploads%2f2018%2f04%2fwhatsapp-icon.png&ehk=%2fGSNSk4y8vLd2qCiosXRI0WSYOth7SLdJewCXSxpcmY%3d&risl=&pid=ImgRaw&r=0" type="image/jpg">

    <?php
    session_start();
    //poner cookie
    setcookie("usuario", $_SESSION['usuario'], time() + 3600, "/");  // Cookie por 1 hora

    if (!isset($_SESSION['usuario'])) {
        echo "<script>window.location.href = 'login.php';</script>";
        exit();
    }

    $conexion = mysqli_connect("localhost", "root", "", "foro");

    // Realizamos la consulta para obtener todas las publicaciones
    $consulta = "SELECT * FROM publicaciones ORDER BY fecha DESC"; // Ordenamos por fecha descendente
    $resultado = mysqli_query($conexion, $consulta);
    ?>
    </head>

    <body>
    <nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
                <li><a href="crearusuario.php">Registrarse</a></li>
                <li><a href="login.php">Iniciar sesión</a></li>
                <li><a href="cierre.php">Cerrar sesión</a></li>
                <li><a href="eliminar.php">Eliminar cuenta</a></li>
                <li><a href="perfil.php">Foro</a></li>

        </ul>
    </nav>

        <div class="header">
            <h1>Bienvenid@, <?php echo($_SESSION['usuario']); ?>!</h1>
        </div>

        <table border="1px">
            <tr>
                <th></th>
                <th>Autor</th>
                <th>Titulo</th>
                <th>Fecha</th>
                <th>Respuestas</th>
            </tr>

        <?php
        if (mysqli_num_rows($resultado) > 0) {
            while ($columnas = mysqli_fetch_assoc($resultado)) {
                // Usamos 'id_publicacion' como el identificador único
                echo "<tr>";
                echo "<td class='ver'><a href='respuesta.php?id=" . $columnas['id_publicacion'] . "'>Ver</a></td>";
                echo "<td>" . $columnas['autor'] . "</td>";
                echo "<td>" . $columnas['titulo'] . "</td>";
                echo "<td>" . $columnas['fecha'] . "</td>";

                // Mostrar el número de respuestas si existe
                $id_publicacion = $columnas['id_publicacion'];
                $consulta_respuestas = "SELECT COUNT(*) as total_respuestas FROM respuestas WHERE id_publicacion = '$id_publicacion'";
                $resultado_respuestas = mysqli_query($conexion, $consulta_respuestas);
                $row_respuestas = mysqli_fetch_assoc($resultado_respuestas);
                echo "<td>" . $row_respuestas['total_respuestas'] . "</td>";

                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No hay publicaciones en el foro.</td></tr>";
        }
        ?>

    </table>
            <p style="text-align:center;"><a class="tema" href="insertatema.php">Añadir un nuevo tema</a></p>
            <p style="text-align:center;"><a class="tema" href="eliminartema.php">Eliminar un tema</a></p>
        </body>
</html>
