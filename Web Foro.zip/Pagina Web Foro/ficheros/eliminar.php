<?php
// Iniciar la sesión
session_start();

// Verificar si la cookie de usuario está presente
if (!isset($_COOKIE['usuario'])) {
    // Redirigir a login si no hay cookie
    echo "<script>window.location.href = 'login.php';</script>";
    exit();
}

// Conectar a la base de datos
$conexion = new mysqli("localhost", "root", "", "foro");

// Verificar la conexión a la base de datos
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Comprobamos si el formulario ha sido enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificamos si el texto ingresado es correcto
    if (isset($_POST['confirmacion']) && $_POST['confirmacion'] === 'eliminar cuenta') {
        // Obtener el ID de usuario desde la cookie
        $usuario = $_COOKIE['usuario'];

        // Eliminar primero las respuestas del usuario
        $conexion->query("DELETE FROM respuestas WHERE usuario = '$usuario'");

        // Eliminar las publicaciones asociadas al usuario
        $conexion->query("DELETE FROM publicaciones WHERE autor = '$usuario'");

        // Eliminar la cuenta del usuario de la base de datos
        $conexion->query("DELETE FROM usuario WHERE usuario = '$usuario'");

        // Eliminar la cookie de usuario
        setcookie('usuario', '', time() - 3600, '/');

        // Redirigimos a la página de inicio después de eliminar
        header('Location: index.php');
        exit();
    }
}


$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Cuenta</title>
    <link rel="stylesheet" href="estilo_default.css">
        <link rel="stylesheet" href="estilo_eliminar.css">
        <link rel="icon" href="https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/TrumpPortrait.jpg/220px-TrumpPortrait.jpg" type="image/png">
</head>
<body>
<nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
                <li><a href="crearusuario.php">Registrarse</a></li>
                <li><a href="login.php">Iniciar sesión</a></li>
                <li><a href="cierre.php">Cerrar sesión</a></li>
                <li><a href="eliminar.php">Eliminar cuenta</a></li>
                <li><a href="perfil.php">Foro</a></li>
        </ul>
    </nav>
    <h1>Eliminar cuenta</h1>
    <form method="POST">
        <label for="confirmacion">Escribe "eliminar cuenta" para confirmar:</label>
        <input type="text" id="confirmacion" name="confirmacion" required>
        <br><br>
        <button type="submit" >Eliminar Cuenta</button>
    </form>

</body>
</html>
