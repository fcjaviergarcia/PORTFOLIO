/*APROBADO 5-6,9
NOTABLE 7-8,9
SOBRESALIENTE 9 - 9,9
MATRICULA DE HONOR: 10
Para promover al siguiente nivel, las tres notas deben ser iguales o mayores a 5.
En el caso de que una de las notas sea menor a 5, se le indicara al estudiante por medio de alert, 
que lleva esa asignatura pendiente y no podra hacer las practicas, hasta tanto no apruebe la 
asignatura. Si dos de las tres notas son menores a 5. Se le indica al alumno que debe repetir el 
curso.
Si el alumno tiene cada nota aprobada, el alert dira: Puede iniciar su peraodo de practicas.
*/
document.getElementById("calcular").addEventListener("click", function ()
{
//RECOGER DATOS
let nombre = document.getElementById("nombre").value;
let apellido1 = document.getElementById("apellido1").value;
let apellido2 = document.getElementById("apellido2").value;
let nota1= parseFloat(document.getElementById("nota1").value);
let nota2= parseFloat(document.getElementById("nota2").value);
let nota3= parseFloat(document.getElementById("nota3").value);

//CALCULAR PROMEDIO

let promedio = (nota1+ nota2 + nota3) / 3;
//CALCULAR ASGINATURAPENDIENTE
let asignaturapendiente=0;
if (nota1 < 5){
    asignaturapendiente++;
    window.alert("LLevas la primera asignatura");
}
if (nota2 < 5){
    asignaturapendiente++;
    window.alert("LLevas la segunda asignatura");
}
if (nota3 < 5){
    asignaturapendiente++;
    window.alert("LLevas la tercera asignatura");
}
if(nota1 < 5 && nota2 <5 ){
    window.alert("Tienes que repetir");
}
if(nota3 < 5 && nota2 <5 ){
    window.alert("Tienes que repetir");
}
if(nota1 < 5 && nota3 <5 ){
    window.alert("Tienes que repetir");
}
if (promedio >=0 && promedio <5)
    {
        window.alert("LLevas " + asignaturapendiente + " asignaturas pendientes " + "y tu promedio es " + promedio.toFixed(2) + "( suspenso)");
    }
    else if (promedio >=5 && promedio <7)
    {
        window.alert("LLevas " + asignaturapendiente + " asignaturas pendientes " + "y tu promedio es " + promedio + "( aprobado)");
    }
        else if (promedio >=7 && promedio <9) {
            window.alert("LLevas " + asignaturapendiente +  " asignaturas pendientes " + "y tu promedio es " + promedio.toFixed(2) + "( notable)");
        }else if(promedio >=9 && promedio <10) {
            window.alert("LLevas " + asignaturapendiente +  " asignaturas pendientes " + "y tu promedio es " + promedio.toFixed(2) + "( sobresaliente)");
        }else if(promedio==10) {
            window.alert("LLevas " + asignaturapendiente +  " asignaturas pendientes " +  "y tu promedio es " + promedio.toFixed(2) + "( matricula de honor)");
        }
       
        if(promedio =>5 && nota1 >=5 && nota2 >=5 && nota3 >=5)
        {
            window.alert("PUEDES COMENZAR LAS PRACTICAS");
        }
    
    }
)